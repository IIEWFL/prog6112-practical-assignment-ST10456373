/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author PEACE
 */
public class MainLibraryTest {
    
    public MainLibraryTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of main method, of class MainLibrary.
     */
    @Test
    //This is the main method().
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        MainLibrary.main(args);
      
    }

    @Test
    //implementing booktittle().
    public void testBookTitle() {
        Book book = new Book("The Great Gatsby", "F. Scott Fitzgerald", "978-0743273565");
        assertEquals("The Great Gatsby", book.getTitle());
    }

    @Test
    //implemetning textbooksubject().
    public void testTextbookSubject() {
        Textbook textbook = new Textbook("Introduction to Algorithms", "Cormen et al.", "978-0262033848", "Computer Science", 3);
        assertEquals("Computer Science", textbook.getSubject());
    }

 

    @Test
    
    public void testSearchByAuthor() {
        Book book1 = new Book("The Great Gatsby", "F. Scott Fitzgerald", "978-0743273565");
        Book book2 = new Book("To Kill a Mockingbird", "Harper Lee", "978-0061120084");

        Book[] libraryCatalog = {book1, book2};

        // Assuming the searchAuthor() exists.
        Book foundBook = searchByAuthor(libraryCatalog, "Harper Lee");
        assertNotNull(foundBook);
        assertEquals("To Kill a Mockingbird", foundBook.getTitle());
    }

    // Implementing  the searchByAuthor().

    private Book searchByAuthor(Book[] libraryCatalog, String harper_Lee) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

