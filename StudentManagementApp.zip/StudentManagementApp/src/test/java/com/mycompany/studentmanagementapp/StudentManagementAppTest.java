/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.studentmanagementapp;
import com.mycompany.studentmanagementapp.studentList;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author PEACE
 */
public class StudentManagementAppTest {
    
    public StudentManagementAppTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of main method, of class StudentManagementApp.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        StudentManagementApp.main(args);
    }
       @Test
    public void testCaptureNewStudent() {
        System.out.println("Capture new student");
        List<Student> myList = new ArrayList<>();
           myList.add(new Student(123,"john",23,"j@gmail.com","Maths"));
            myList.add(new Student(123,"john",23,"j@gmail.com","Maths"));
           assertEquals(2, myList.size());
        //StudentManagementApp.captureNewStudent();
        
        String[] args = null;
       
    }
    @Test
    public void testAgeIsValid()
    {
        assertEquals(false, StudentManagementApp.ageIsValid("12")); 
        assertEquals(true, StudentManagementApp.ageIsValid("17")); 
      //  assertEquals(false, StudentManagementApp.ageIsValid("t")); 
        assertTrue(StudentManagementApp.ageIsValid("17"));
        assertFalse(StudentManagementApp.ageIsValid("12"));
    }
    @Test
    public void testSearchStudent() {
     
        //searchStudent("erwe");
        StudentManagementApp.searchStudent();
        // assertEquals(2, myList.size());
    }
    @Test
    public static void testdeleteStudent(){
         System.out.println("Student deleted successfully!");
         return;
    }
    @Test
    public static void testprintStudentReport(){
        Iterable<Student> studentList = null;
         for(Student student : studentList){
            System.out.println("ID: " + student.getID() + ",Name: " + student.getName());
            
        }
    }
}
