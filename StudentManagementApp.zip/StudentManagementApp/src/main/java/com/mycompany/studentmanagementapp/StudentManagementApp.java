/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.studentmanagementapp;

/**
 *
 * @author PEACE
 */

import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.InputMismatchException;
public class StudentManagementApp {
    //Declaration of the Array list with paramentern<Student>.
    private static List<Student> studentList= new ArrayList<>(); 
            

    public static void main(String[] args) {
      Scanner scanner = new Scanner(System.in);
      int choice;
        System.out.println("STUDENT MANAGEMENT APPLICATION");
        System.out.println("*************************************");
        System.out.println("Enter(1) to launch menu or any other key to exit");
        
        String input = scanner.nextLine();
        if (!input.equals("1")){
            System.out.println("Exiting application.Goodbye!");
              return ;
             
        }
        do{//it will provide the menu options on the terminal as ive used scanner not Joptionpane.
            System.out.println("\nMENU:");
            System.out.println("(1) capture a new student ");
            System.out.println("(2) Search for a student");
            System.out.println("(3) Delete a student");
            System.out.println("(4) Print Student report");
            System.out.println("(5) Exit application");
            System.out.println("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();
            //Using advantage of switch method to simplify my code and not using while looop or for loop. 
            switch (choice){
                case 1 :captureNewStudent();
                         break;
                case 2 :searchStudent(); 
                         break;
              
                case 3 : deleteStudent();
                         break;

                case 4 : printStudentReport();
                         break;

                case 5 : 
                    System.out.println("Existing application, Goobye!");
             //default acts to make sure once all cases are checked it just provides an option if all cases are not considered. 
                default: System.out.println("Invalid choice . Please try again");                    
            }
         //will run through the program till condion = 5 is true.
        }while(choice != 5);
    }
    //This method captures the student information provided by the user .
    public static void captureNewStudent(){
       Scanner scanner = new Scanner (System.in);
        System.out.println("\nEnter student details:");
        System.out.println("Student ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        //This consumes the newlne.
        System.out.println("Name: ");
        String name = scanner.nextLine();
        String ageString;
        do {
         System.out.println("Age: ");
         ageString = scanner.next();
        } while ( !ageIsValid(ageString));
        
         int age = Integer.parseInt(ageString);
        scanner.nextLine();
        // consume newline
        System.out.println("Email: ");
        String email= scanner.nextLine();
        System.out.println("Course: ");
        String course = scanner.nextLine();
        studentList.add(new Student(id,name,age,email,course));
        System.out.println("Student details saved successfully!");
    }    
    //checks if the age is valid(above or equal to 16).
    public static boolean ageIsValid(String ageString)
    {
         try {
            int age = Integer.parseInt(ageString);
          //if provided with the condition that checks agevalidility.
          if(age < 16){
              System.out.println("Invalid age.Must be 16 or older.");
                return false;
           } else{
              System.out.println("valid age.");
              return true;}
        //catches anything that the user shall input and provide feed back in println.
        } catch(InputMismatchException e){
            System.out.println("Invalid input for age .Please enter a valid number.");
            return false;
         }
    }
    //provides option to search for a student ()in the memory of the application.
    public static void searchStudent(){
      Scanner scanner = new Scanner(System.in);
      System.out.println("\nEnter student ID to search: ");
      int searchId = scanner.nextInt();
      for(Student student : studentList){
          if (student.getID() == searchId){
           System.out.println("Student found: ");
             System.out.println("ID: " + student.getID());
             System.out.println("Name: " + student.getName());
             System.out.println("Age: " + student.getAge());
             System.out.println("Email: " + student.getEmail());
             System.out.println("Course: " + student.getCourse());
             return;
             
          }
      }
        System.out.println("Student not found.");
    }
    //deletes the  student that is entered on delete window.
    public static void deleteStudent(){
      Scanner scanner =  new Scanner(System.in);
      System.out.println("\nEnter student ID to delete: ");
      int deleteId = scanner.nextInt();//accepts the student id entred by user to search and delete within the application.
      for(Student student : studentList){
         if(student.getID()== deleteId){
         studentList.remove(student);
         System.out.println("Student deleted successfully!");
         return;
         }
      }
        System.out.println("Student not found.");
    }
    //Prints out a full report of all the students entered/stored in memory.
    public static void printStudentReport(){
        System.out.println("\nStudent Report:");
        for(Student student : studentList){
            System.out.println("ID: " + student.getID() + ",Name: " + student.getName());
            
        }
    }
}
