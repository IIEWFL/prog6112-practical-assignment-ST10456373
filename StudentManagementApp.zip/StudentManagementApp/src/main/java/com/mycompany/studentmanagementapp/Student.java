package com.mycompany.studentmanagementapp;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author PEACE
 */
import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.InputMismatchException;

 class Student {
    private int id;
    private String name; 
    private int age;
    private String email;
    private String course;
    
    
    
    //Introduction of Constructor
    public Student(int id, String name , int age , String email ,String course ){
      this.id = id; 
      this.name= name;
      this.age=age;
      this.email=email;
      this.course=course; 
    }
    //This is a getters ,you use .get to access the private attributes. 
    public int getID(){
      return id;
    }
    public String getName(){
      return name;
    }
    public String getEmail(){
      return email;
    }
    public int getAge(){
      return age;
    }
    public String getCourse(){
     return course;
    }
    
    
}
