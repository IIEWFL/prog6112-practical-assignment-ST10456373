/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany;

/**
 *
 * @author PEACE
 */
public class MainLibrary {
    public static void main(String[] args) {
        // Create some books and textbooks
        Book book1 = new Book("The Great Gatsby", "F. Scott Fitzgerald", "978-0743273565");
        Textbook textbook1 = new Textbook("Introduction to Algorithms", "Cormen et al.", "978-0262033848", "Computer Science", 3);

        // Store them in an array (you can add more)
        Book[] libraryCatalog = {book1, textbook1};

        // Search for a book by title
        String searchTitle = "The Great Gatsby";
        for (Book book : libraryCatalog) {
            if (book.getTitle().equalsIgnoreCase(searchTitle)) {
                System.out.println("Found book: " + book.getTitle() + " by " + book.getAuthor());
            }
        }

        // Search for a book by author
        String searchAuthor = "Cormen";
        for (Book book : libraryCatalog) {
            if (book.getAuthor().contains(searchAuthor)) {
                System.out.println("Found book: " + book.getTitle() + " (Author: " + book.getAuthor() + ")");
            }
        }
    }
}