/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany;

/**
 *
 * @author PEACE
 */
public class Textbook extends Book {
    private String subject;
    private int edition;

    public Textbook(String title, String author, String isbn, String subject, int edition) {
        super(title, author, isbn);
        this.subject = subject;
        this.edition = edition;
    }

    // Additional getters for subject and edition
    public String getSubject() {
        return subject;
    }

    public int getEdition() {
        return edition;
    }
}